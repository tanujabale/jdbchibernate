package com.first;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Delete {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			Connection co = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","12345678");
		    Statement st = co.createStatement();
		    int a = st.executeUpdate("DELETE FROM studentinfo WHERE rollno=1;");
		    System.out.println("delete");
		    
		    }catch(SQLException e) {
		    	e.printStackTrace();
		    }

	}
}
