package com.first;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Update {
	public static void main(String[] args) {
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		Connection co = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","12345678");
	    Statement st = co.createStatement();
	    int rowsaffected=st.executeUpdate("UPDATE studentinfo SET name='aaa' WHERE city='satara'");
	    System.out.println("update"+rowsaffected);
	    }catch(SQLException e) {
	    	e.printStackTrace();
	    }
	}

}
