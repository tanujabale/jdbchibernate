package com.first;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class First {
	public static void main(String[] args) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		}catch(ClassNotFoundException e) {
			e.printStackTrace();
		}
		String url="jdbc:mysql://localhost:3306/student";
		String username ="root";
		String pass ="12345678";
	try {
	Connection co = DriverManager.getConnection(url,username,pass);
	Statement st = co.createStatement();
	ResultSet executeQuery = st.executeQuery("SELECT * FROM studentinfo");
	while(executeQuery.next()){
		int rollno = executeQuery.getInt("rollno");
		String name = executeQuery.getString("name");
		String city = executeQuery.getString("city");
		System.out.println("rollNo:"+rollno+"\nname:"+name+"\ncity:"+city);
	}
	}catch(SQLException e){
		e.printStackTrace();	
	}
}
}