package com.first;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class Insert_prepared {
public static void main(String[] args) {
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		Scanner sc = new Scanner(System.in);
		Connection co = DriverManager.getConnection("jdbc:mysql://localhost:/student","root","12345678");
		PreparedStatement st = co.prepareStatement("INSERT INTO studentinfo(rollno,name,city)VALUES(?,?,?);");
		System.out.println("Enter a data:");
		int roll = sc.nextInt();
		String name = sc.next();
		String city = sc.next();
		st.setInt(1, roll);
		st.setString(2,name);
		st.setString(3, city);
		st.executeUpdate();
		System.out.println("done");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}
}
