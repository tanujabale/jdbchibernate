package com.first;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PreparedStatementt {
public static void main(String[] args) {
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
	try {
		Connection co = DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","12345678");
		PreparedStatement ct = co.prepareStatement("INSERT INTO studentinfo(rollno,Name,city)VALUES(?,?,?);");
		ct.setInt(1,100);
		ct.setString(2,"riyaaa");
		ct.setString(3,"gujrat");
		int a =  ct.executeUpdate();
		System.out.println("done"+a);
	} catch (SQLException e) {
		e.printStackTrace();
	}
}
}
