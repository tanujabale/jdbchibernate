package com.project.candidate.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.project.candidate.Candidate;

public class Database {
	public static void SavetoDb(ArrayList<Candidate>list) {
		Connection cn = Connect.getConnect();
		try {
			int op=0;
		PreparedStatement st = cn.prepareStatement("INSERT INTO candidate(id,name,party,age)VALUES(?,?,?,?)");
		for(Candidate cd:list) {
			int id =cd.getId();
			String name = cd.getName();
			int age =cd.getAge();
			String party = cd.getParty();
			st.setInt(1,id);
			st.setString(2, name);
			st.setInt(3, age);
			st.setString(4, party);
		
		int ch = st.executeUpdate();
		op=op+ch;
		
		}System.out.println("data successfully saved");
 }catch(SQLException e) {
		e.printStackTrace();
	}
}
	public static void updateCandidate(){
		Scanner sc = new Scanner(System.in);
		Connection co = Connect.getConnect();
		try {
			System.out.println("press 1 for id\npress 2 for name\npress 3 for age\npress 4 for party");
			int ch = sc.nextInt();
			switch(ch) {
			case 1:
				PreparedStatement st = co.prepareStatement("update candidate set name=? where id=?;");
				System.out.println("enter new name");
				st.setString(1,sc.next());
				System.out.println("enter id of candidate");
				st.setInt(2,sc.nextInt());
				int ex= st.executeUpdate();
				System.out.println(ex+"data upadated");
				break;
			case 2 :
				PreparedStatement st1 = co.prepareStatement("update candidate set party=? where id=?;");
				System.out.println("enter new party");
				st1.setString(1,sc.next());
				System.out.println("enter id of candidate");
				st1.setInt(2,sc.nextInt());
				int ex1= st1.executeUpdate();
				System.out.println(ex1+"data upadated");
				break;
			case 3:
				PreparedStatement st3 = co.prepareStatement("update candidate set age=? where id=?;");
				System.out.println("enter new age");
				st3.setString(1,sc.next());
				System.out.println("enter id of change");
				st3.setInt(2,sc.nextInt());
				int ex3= st3.executeUpdate();
				System.out.println(ex3+"data upadated");
				break;
			}}catch(SQLException e) {
					e.printStackTrace();
				}
}
	public static void DeleteCandidate() {
		Scanner sc = new Scanner(System.in);
		Connection co=Connect.getConnect();	
		System.out.println("Enter id for delete");
		try {
			PreparedStatement st= co.prepareStatement("DELETE FROM  candidate WHERE id=?;");
			int id=sc.nextInt();
			System.out.println("Are you sure want to delete id:"+id);
			System.out.println("Press 1 for delete 2 for cancel:");
			int sure =sc.nextInt();
			if(sure==1) {
				st.setInt(1, id);
				int a=st.executeUpdate();
				System.out.println("Deleted");
			}else {
				System.out.println("Cancelled");
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
		}
	public static void DisplayCandidate() {
		Connection co=Connect.getConnect();
		try {
			Statement st=co.createStatement();
			ResultSet a=st.executeQuery("SELECT *  FROM  candidate;");
			while(a.next()) {
				int id=a.getInt("id");
				String name=a.getString("name");
				int age=a.getInt("age");
				String party=a.getString("party");
				
				System.out.println("id: "+id+" name:"+name+" age: "+age+" party: "+party);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}

