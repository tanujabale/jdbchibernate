package com.project.candidate;

import java.util.Scanner;

import com.project.candidate.Database.Database;

public class Operation {
	static Scanner sc = new Scanner(System.in);
	Multicandidate ml = new Multicandidate();
	public static void setcandidate() {
		int ch =1;
		while(ch==1) {
			Multicandidate ml = new Multicandidate();
		Candidate obj=new Candidate();
		System.out.println("Enter a id:");
		int id = sc.nextInt();
		obj.setId(id);
		System.out.println("Enter a name:");
	    String name = sc.next();
		obj.setName(name);
		System.out.println("Enter party:");
		String party = sc.next();
	    obj.setParty(party);
	    System.out.println("Enter a Age:");
		int age = sc.nextInt();
		obj.setAge(age);
	    ml.addCandidate(obj);
		System.out.println("Press 1 for add more Candidate\n press 2 for save all candidate");
		ch=sc.nextInt();
		if(ch==2){
			ml.save();
	}}
	}
		public static void CandidateOperation() {
			System.out.println("press 1 for register candidate\npress 2 for update candidate\npress 3 for delete candidate\npress 4 for display candidate");
			int ch = sc.nextInt();
			switch(ch) {
			case 1:
				Operation.setcandidate();
				break;
			case 2:
				Database.updateCandidate();
				break;
			case 3:
				Database.DeleteCandidate();
				break;
			case 4 :
				Database.DisplayCandidate();
				break;
			}
}
}