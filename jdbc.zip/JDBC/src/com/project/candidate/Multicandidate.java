package com.project.candidate;

import java.util.ArrayList;

import com.project.candidate.Database.Database;

public class Multicandidate {
	 public ArrayList<Candidate> list;
	
	public Multicandidate() {
		this.list=new ArrayList<Candidate>();			
	}
	public void addCandidate(Candidate cd) {
		list.add(cd);
	}
	public void save() {
		Database.SavetoDb(list);
		System.out.println("Data Added Successfully");
	}
	

}
