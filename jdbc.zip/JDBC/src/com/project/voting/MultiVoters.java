package com.project.voting;

import java.util.ArrayList;

import com.project.voting.Database.DatabaseVoting;

public class MultiVoters {
	private ArrayList<Voters> list;
	
	public MultiVoters() {
		this.list=new ArrayList<Voters>();			
	}
	public void addCandidate(Voters vt) {
		list.add(vt);
	}
	public void save() {
		DatabaseVoting.SavetoDb(list);
		System.out.println("Data Added Successfully");
	}
	

}

