package com.project.voting.Database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

import com.project.candidate.Database.Connect;
import com.project.voting.Voters;

public class DatabaseVoting {
	public static void SavetoDb(ArrayList<Voters>list) {
		Connection cn = Connect.getConnect();
		int op=0;
		try {
		PreparedStatement st = cn.prepareStatement("INSERT INTO VOTERS(name,age,gender,area)VALUES(?,?,?,?)");
		for(Voters mv:list) {
			String name = mv.getName();
			String gender = mv.getGender();
			int age =mv.getAge();
			String area = mv.getArea();
			st.setString(1, name);
			st.setInt(2, age);
			st.setString(3, gender);
			st.setString(4, area);
			op = st.executeUpdate();
		System.out.println(op+"candidate added successfully");
	} }catch(SQLException e) {
		e.printStackTrace();
	}
}
	public static void updateVoters(){
		Scanner sc = new Scanner(System.in);
		Connection co = Connect.getConnect();
		try {
			System.out.println("press 1 for id\npress 2 for name\npress 3 for age\npress 4 for gender\npress 5 for Area");
			int ch = sc.nextInt();
			switch(ch) {
			case 1:
				PreparedStatement st = co.prepareStatement("update voters set name=? where id=?;");
				System.out.println("enter new name");
				st.setString(1,sc.next());
				System.out.println("enter id of Voter");
				st.setInt(2,sc.nextInt());
				int ex= st.executeUpdate();
				System.out.println(ex+"data upadated");
				break;
			case 2 :
				PreparedStatement st1 = co.prepareStatement("update voters set area=? where id=?;");
				System.out.println("enter new Area");
				st1.setString(1,sc.next());
				System.out.println("enter id of candidate");
				st1.setInt(2,sc.nextInt());
				int ex1= st1.executeUpdate();
				System.out.println(ex1+"data upadated");
				break;
			case 3:
				PreparedStatement st3 = co.prepareStatement("update voters set age=? where id=?;");
				System.out.println("enter new age");
				st3.setString(1,sc.next());
				System.out.println("enter id of change");
				st3.setInt(2,sc.nextInt());
				int ex3= st3.executeUpdate();
				System.out.println(ex3+"data upadated");
				break;
			}}catch(SQLException e) {
					e.printStackTrace();
				}
}
	public static void DeleteVoters() {
		Scanner sc = new Scanner(System.in);
		Connection co=Connect.getConnect();	
		System.out.println("Enter id for delete");
		try {
			PreparedStatement st= co.prepareStatement("DELETE FROM  voters WHERE id=?;");
			int id=sc.nextInt();
			System.out.println("Are you sure want to delete id:"+id);
			System.out.println("Press 1 for delete 2 for cancel:");
			int sure =sc.nextInt();
			if(sure==1) {
				st.setInt(1, id);
				int a=st.executeUpdate();
				System.out.println("Deleted");
			}else {
				System.out.println("Cancelled");
			}
		}catch (SQLException e) {
			e.printStackTrace();
		}
		
		}
	public static void DisplayVoters() {
		Connection co=Connect.getConnect();
		try {
			Statement st=co.createStatement();
			ResultSet a=st.executeQuery("SELECT *  FROM  voters;");
			while(a.next()) {
				int id=a.getInt("id");
				String name=a.getString("name");
				int age=a.getInt("age");
				String gender=a.getString("gender");
				String area =a.getString("area");
				
				System.out.println("id: "+id+" name:"+name+" age: "+age+" gender: "+gender+"area:"+area);
				
			}
		} catch (SQLException e) {
			e.printStackTrace();
			}
			
		}
	}


