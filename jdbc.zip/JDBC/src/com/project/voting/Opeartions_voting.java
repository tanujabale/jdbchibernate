package com.project.voting;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.project.voting.Database.Connect;
import com.project.voting.Database.DatabaseVoting;

public class Opeartions_voting {
	static MultiVoters mv = new MultiVoters();
	static Scanner sc = new Scanner(System.in); 
	public static void setvoters(int ids) {
		int ch=1;
		while(ch==1) {
			Voters vt = new Voters();
		System.out.println("Enter a id ");
		int id =sc.nextInt();
		vt.setId(id);
		System.out.println("Enter a name");
		String name = sc.next();
		vt.setName(name);
		System.out.println("Enter age");
		int age=sc.nextInt();
		vt.setAge(age);
		System.out.println("Enter gender");
		String gender=sc.next();
		vt.setGender(gender);
		System.out.println("Enter Area");
		String area=sc.next();
		vt.setArea(area);
		System.out.println("\nPress 1 for add more Voter\n press 2 for save all voting");
		ch=sc.nextInt();
		
		if(ch==2){
			mv.save();
		}}}
		public static void VotersOperation() {
			System.out.println("press 1 for register for voting\npress 2 for update Voting\npress 3 for delete voting\npress 4 for display Voting");
			int ch = sc.nextInt();
			switch(ch) {
			case 1:
				Opeartions_voting.setvoters(ch);
				break;
			case 2:
				DatabaseVoting.updateVoters();
				break;
			case 3:
				DatabaseVoting.DeleteVoters();
				break;
			case 4 :
				DatabaseVoting.DisplayVoters();
				break;
			}
		}public void setId() {
			Connection cn=Connect.getConnect();
			
			try {
				int op=0;
				Statement st=cn.createStatement();
				ResultSet source=st.executeQuery("select id from candidate");
				PreparedStatement destination=cn.prepareStatement("Insert into voting(id)values(?)");
				
				while(source.next()) {
					int ids=source.getInt("id");
					destination.setInt(1, ids);
					int n=destination.executeUpdate();
					op=op+n;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}}
		public static void startVoting() {
			System.out.println("Enter voter Id:");
			int voterId=sc.nextInt();
			
			Connection co = Connect.getConnect();
			try {
				Statement st = co.createStatement();
				ResultSet rst = st.executeQuery("Select id from voters");
				
				boolean found = false;
				while(rst.next()) {
					int ids = rst.getInt("id");{
						System.out.println("successfull");
						Opeartions_voting.setvoters(ids);
						found = true;
						break;
					}
				}
				if(found==false) {
					Opeartions_voting vo = new Opeartions_voting();
					System.out.println("invalid voter");
				}
			}catch(SQLException e) {
				e.printStackTrace();
				}
			}public static void  finalCandidate(){
				Connection co=Connect.getConnect();
				try {
				Statement st=co.createStatement();
				ResultSet rt=st.executeQuery("Select * from Candidate;");
				while(rt.next()) {
					int id=rt.getInt("id");
					String name=rt.getString("name");
					String vote=rt.getString("vote");
					String party=rt.getString("party");
					int age=rt.getInt("age");
					System.out.println("id:"+id+"\tname:"+name+"\tvote:"+vote+"\tparty:"+party+"\tage:"+age);
				}
				} catch (SQLException e) {
					e.printStackTrace();
				}}
		public static void setVote(int ids) {
			Opeartions_voting.finalCandidate();
			System.out.println("choose your candidate");
			Scanner sc = new Scanner(System.in);
			int id =sc.nextInt();
			Connection co = Connect.getConnect();
			try {
				PreparedStatement pst = co.prepareStatement("select voter from voting where id=?");
				pst.setInt(1, id);
				ResultSet rst=pst.executeQuery();
				while(rst.next()) {
					int singlevote = rst.getInt("votes");
					singlevote = singlevote+1;
					PreparedStatement voting = co.prepareStatement("update voting SET votes=? where id =?");
					voting.setInt(1, singlevote);
					voting.setInt(2, id);
					voting.executeUpdate();
					System.out.println("vote success");
				}
			}catch(SQLException e) {
				e.printStackTrace();
			}
		}
}

