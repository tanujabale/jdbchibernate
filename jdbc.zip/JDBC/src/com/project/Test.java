package com.project;

import java.util.Scanner;

import com.project.candidate.Operation;
import com.project.voting.Opeartions_voting;

public class Test {
 static {
	 System.out.println("welcome to election");
 }
 static Scanner sc = new Scanner(System.in);
 static Opeartions_voting v=new Opeartions_voting();
 public static void main(String[] args) {
	System.out.println("Press 1 for candidate\npress 2 for voting seats\npress 3 for start voting ");
	int ch = sc.nextInt();
	switch(ch) {
	case 1:
		Operation.setcandidate();
		break;
	case 2:
		Opeartions_voting.VotersOperation();
		break;
	case 3:
		v.setId();
		Opeartions_voting.startVoting();
		break;
	}
}
 
}
