package com.customerdata;

import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

public class App3 {
	public static void main(String[] args) {
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	      //Session session = factory.getCurrentSession();
	      Transaction ts = session.beginTransaction();
	      
	      Customer cs = new Customer();
	      cs.setId(1);
	      cs.setName("riya");
	      
	      Customer cs1=new Customer();
	      cs1.setId(2);
	      cs1.setName("mrunali");
	      SessionFactory factory1=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	    	Session currentSession=factory.openSession();
	    	Customer cst=currentSession.get(Customer.class, 1);
	    	System.out.println(cst.getId());
	    	System.out.println(cst.getName());
	    	currentSession.close();
	    	factory.close();
	
	     //*****Delete the data*****//
	     Scanner sc=new Scanner(System.in);
	     int ch=sc.nextInt();
	     Query q=session.createQuery("delete from Contact c where c.voter.id= :ch");
	     q.setParameter("ch", ch);
	     q.executeUpdate();
	     ts.commit();
	     System.out.println("deleted");
	     System.out.println("done");
	     session.close();
	     factory.close();
	}
	
}
