package com.voter.VoterContact;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
@Entity
public class Contact {
	@Id
private int num;
	
	private String name;
	
private int contactid;

@ManyToOne
private Voter voter;

public int getnum() {
	return num;
}

public void setnum(int id) {
	this.num = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public int getContactid() {
	return contactid;
}

public void setContactid(int contactid) {
	this.contactid = contactid;
}

public Voter getVoter() {
	return voter;
}

public void setVoter(Voter voter) {
	this.voter = voter;
}

@Override
public String toString() {
	return "Contact [num=" + num + ", name=" + name + ", contactid=" + contactid + ", voter=" + voter + "]";
}

public Contact(int id, String name, int contactid, Voter voter) {
	super();
	this.num = id;
	this.name = name;
	this.contactid = contactid;
	this.voter = voter;
}

public Contact() {
	super();
	// TODO Auto-generated constructor stub
}}