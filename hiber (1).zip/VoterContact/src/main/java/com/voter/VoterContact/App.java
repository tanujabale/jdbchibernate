package com.voter.VoterContact;



import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.hibernate.NonUniqueObjectException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;


/**
 * Hello world!
 *
 */
public class App  {
    public static void main( String[] args ){
    	SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
       // Session session = factory.getCurrentSession();
       // Transaction ts = session.beginTransaction();
//        Contact cn = new Contact();
//      cn.setContactid(1);
//      cn.setnum(987668);
//      
//      Contact cn1 = new Contact();
//      cn1.setContactid(2);
//      cn1.setnum(987668678);
//      
//      Contact cn2 = new Contact();
//      cn2.setContactid(3);
//      cn2.setnum(98766);
//      
//      Contact cn3 = new Contact();
//      cn3.setContactid(4);
//      cn3.setnum(987668000);
//      
//      List<Contact>contactlist=new ArrayList<Contact>();
//      contactlist.add(cn);
//      contactlist.add( cn1);
//      contactlist.add( cn2);
//      contactlist.add( cn3);
//      
////      Voter vt = new Voter();
////      vt.setId(1);
////      vt.setName("agusu");
////      vt.setContact(contactlist);
//      Voter vt= new Voter();
//      vt.setId(1);
//      vt.setName("mrunali");
//      vt.setContact(contactlist);
//      
//      cn.setVoter(vt);
//      cn1.setVoter(vt);
//      cn2.setVoter(vt);
//      cn3.setVoter(vt);
//      session.save(vt);
//      session.save(cn);
//      session.save(cn1);
//      session.save(cn2);
//      session.save(cn3);
//      
      
      //Transaction tn=session.beginTransaction();
//    Scanner sc=new Scanner(System.in);
//     int ch=sc.nextInt();
//     Query q=session.createQuery("delete from Contact c where c.voter.id= :ch");
//     q.setParameter("ch", ch);
//     q.executeUpdate();
//     ts.commit();
//     System.out.println("deleted");
//         //ts.commit();
//        System.out.println("done");
//        session.close();
//        factory.close();
	}
    //Transaction tn=session.beginTransaction();
//    Scanner sc=new Scanner(System.in);
//    System.out.println("Enter Id");
//     int ch=sc.nextInt();
//     Query q=session.createQuery("update Voter set name= :name where id= :ch");
//     
//     System.out.println("Enter name");
//     String next=sc.next();
//     
//     q.setParameter("ch", ch);
//     q.setParameter("name", next);
//     q.executeUpdate();
//     tn.commit();
//     System.out.println("updated");
//    }
