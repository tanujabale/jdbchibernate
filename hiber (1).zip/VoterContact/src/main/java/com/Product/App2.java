package com.Product;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class App2 {
	public static void main(String[] args) {
		SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
	      Session session = factory.getCurrentSession();
	      Transaction ts = session.beginTransaction();
	      
	     Product pt = new Product ();
	     pt.setP_id(1);
	     pt.setP_name("cloths");

	     
	     Product pt1 = new Product();
	     pt1.setP_id(2);
	     pt1.setP_name("Grocery");
	      
	     session.save(pt);
	     session.save(pt1);
	     ts.commit();
	     System.out.println("done");
	     session.close();
	     factory.close();
	}
}
