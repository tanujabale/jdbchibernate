package com.demo.kbpcoes;

import jakarta.persistence.Embeddable;

@Embeddable
public class ScoreCard {
	private int Marks;
	private char Grade;
	public int getMarks() {
		return Marks;
	}
	public void setMarks(int marks) {
		Marks = marks;
	}
	public char getGrade() {
		return Grade;
	}
	public void setGrade(char grade) {
		Grade = grade;
	}
	@Override
	public String toString() {
		return "ScoreCard [Marks=" + Marks + ", Grade=" + Grade + "]";
	}
	public ScoreCard(int marks, char grade) {
		super();
		Marks = marks;
		Grade = grade;
	}
	public ScoreCard() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
