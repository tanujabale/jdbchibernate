package com.demo.kbpcoes;

import java.util.Arrays;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Lob;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.persistence.Transient;
@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int empId;
	private String empName;
	@Lob
	@Column(length=100000)
	private byte[] img;
	private String city;
	//@Temporal(TemporalType.DATE)
	//private Date date;
	private ScoreCard score;
//	public Date getDate() {
//		return date;
//	}
//	public void setDate(Date date) {
//		this.date = date;
//	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", img=" + Arrays.toString(img) + ", city=" + city+"]";
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public byte[] getImg() {
		return img;
	}
	public void setImg(byte[] img) {
		this.img = img;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Employee(int empId, String empName, byte[] img, String city) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.img = img;
		this.city = city;
		//this.date = date;
	}

}
