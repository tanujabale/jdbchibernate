package com.demo.kbpcoes;


import java.io.FileInputStream;
import java.io.IOException;
import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException
    {
    	Employee s=new Employee();
    	s.setEmpName("Riya");
    	s.setCity("Satara");
    	//s.setDate(new Date());
    
    	Employee s1=new Employee();
    	s1.setEmpName("Mrunali");
    	s1.setCity("Satara");
    	//s1.setDate(new Date());
    	
    	Employee s2=new Employee();
    	s1.setEmpName("sneha");
    	s1.setCity("Satara");
    	
    	Employee s3=new Employee();
    	s1.setEmpName("saee");
    	s1.setCity("Satara");
    	
//    	ScoreCard sc=new ScoreCard();
//    	sc.setMarks(100);
//    	sc.setGrade("A");
//    	s.setScore(sc);
    	
//    	ScoreCard sc1=new ScoreCard();
//    	sc1.setMarks(100);
//    	sc1.setGrade("A");
//    	s1.setScore(sc1);
    	
    
    	
//    	FileInputStream fs=new FileInputStream("src/main/java/flower.jpg");
//    	byte[] a=new byte[fs.available()];
//    	fs.read(a);
//    	s.setImg(a);
    	
    	//to add multiple data
//    	SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
//        Session sn=factory.getCurrentSession();
//        Transaction ts=sn.beginTransaction();
//       // Sample sample=sn.get(Sample.class, 1);
//        //System.out.println(sample.getName());
//        sn.save(s);
//        sn.save(s1);
//        ts.commit();
//        System.out.println("saved");
//        sn.close();
//        factory.close();
           
    	
    	//to get the data
    	/*SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    	Session currentSession=factory.openSession();
    	Sample sample=currentSession.get(Sample.class,2);
    	ScoreCard card=sample.getScore();
//    	ScoreCard card=currentSession.get(ScoreCard.class, 100);
    	System.out.println(sample.getName());
    	System.out.println(card.getGrade());
    	currentSession.close();
    	factory.close();*/
    	
    	// to update the data
//    	SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
//    	Session currentsession=factory.getCurrentSession();
//    	Transaction transaction=currentsession.beginTransaction();
//    	Employee employee=currentsession.get(Employee.class,1);
//    	employee.setCity("Wai");
//    	//employee.setCity("satara");
//    	transaction.commit();
//    	System.out.println("Updated");
//    	currentsession.close();
//    	factory.close();
//    	
    	
    	//to delete the data
    	SessionFactory factory=new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    	Session session=factory.getCurrentSession();
    	Transaction transaction=session.beginTransaction();
    	Employee employee=session.get(Employee.class,1);
    	System.out.println(employee.getEmpName());
    	session.delete(employee);
    	System.out.println("deleted");
    	employee.setCity("pune");

    	System.out.println("Updated");
    	transaction.commit();
    	session.close();
    	factory.close();
    	
        
        
    }
}